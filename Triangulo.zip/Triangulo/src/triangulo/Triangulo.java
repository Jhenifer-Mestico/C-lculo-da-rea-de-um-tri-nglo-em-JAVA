/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package triangulo;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class Triangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double a,b,c;
        
         Scanner inputData = new Scanner(System.in);
    System.out.println("Digite o  lado a do terreno, em m:");
    a = inputData.nextDouble(); 
    
    System.out.println("Digite o lado b do terreno, em m:");
    b = inputData.nextDouble(); 
    
    c = Math.sqrt(a*a + b*b);
     
    System.out.printf("Tera que comprar %2f m(metros) de cerca \n", c);
    System.out.println("Tera que comprar" +c+"m (metros) de cerca");
    }
    
}
